from flask import Flask, render_template, request, redirect, url_for, session
import pymongo
import re
import bcrypt

app = Flask(__name__)
app.secret_key = "testing"
client = pymongo.MongoClient("mongodb://localhost:27017")
db = client.get_database('restaurant')
records = db.register
comment = db.comment
order_db = db.order
customer = db.customer
Data = db.Data
Delivery_boy = db.deliveryboy
menudb = db.menu
order_table = db.ordercontent

@app.route("/", methods=['post', 'get'])
def index():
    message = ''
    if "email" in session:
        return redirect(url_for("logged_in"))
    if request.method == "POST":
        user = request.form.get("fullname")
        email = request.form.get("email")
        utype = request.form.get("utype")
        password1 = request.form.get("password1")
        password2 = request.form.get("password2")

        user_found = records.find_one({"name": user})
        email_found = records.find_one({"email": email})
        if user_found:
            message = 'There already is a user by that name'
            return render_template('registration/index.html', message=message)
        if email_found:
            message = 'This email already exists in database'
            return render_template('registration/index.html', message=message)
        if password1 != password2:
            message = 'Passwords should match!'
            return render_template('registration/index.html', message=message)
        else:
            hashed = bcrypt.hashpw(password2.encode('utf-8'), bcrypt.gensalt())
            user_input = {'name': user, 'email': email, 'password': hashed, 'user':utype}
            records.insert_one(user_input)

            user_data = records.find_one({"email": email})
            new_email = user_data['email']

            return render_template('registration/logged_in.html', email=new_email)
    return render_template('registration/index.html')

@app.route('/hello')
def hello():
    return '<h1>Hello, World!</h1>'

@app.route("/login_delivery", methods=["POST","GET"])
def login_d():
    message = 'Please login to your account'
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        utype = request.form.get("utype")
        if utype == 'delivery_boy':
            username_found = Delivery_boy.find_one({"name": username})
            if username_found:
                username_val = username_found['name']
                passwordcheck = username_found['password']

                if bcrypt.checkpw(password.encode('utf-8'), passwordcheck):
                    session["name"] = username_val
                    return redirect(url_for('login_d'))
                else:
                    if "username" in session:
                        return redirect(url_for("login_d"))
                    message = 'Wrong password'
                    return render_template('registration/login.html', message=message)
            else:
                message = 'Email not found'
                return render_template('registration/login.html', message=message)
    return render_template('registration/login.html', message=message)

@app.route("/login", methods=["POST", "GET"])
def login():
    message = 'Please login to your account'
    if "email" in session:
        return redirect(url_for("logged_in"))

    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        email_found = records.find_one({"email": email})
        if email_found:
            email_val = email_found['email']
            passwordcheck = email_found['password']

            if bcrypt.checkpw(password.encode('utf-8'), passwordcheck):
                session["email"] = email_val
                print('1')
                return redirect(url_for('logged_in'))
            else:
                if "email" in session:
                    print('2')
                    return redirect(url_for("logged_in"))
                message = 'Wrong password'
                print('3')
                return render_template('registration/login.html', message=message)
        else:
            message = 'Email not found'
            print('4')
            return render_template('registration/login.html', message=message)
        print('5')
        return render_template('user/order.html', message=message)
    print('6')
    return render_template('registration/login.html', message=message)

@app.route('/logged_in')
def logged_in():
    if "email" in session:
        email = session["email"]
        return render_template('registration/logged_in.html', email=email)
    else:
        return redirect(url_for("login"))

@app.route("/register")
def register():
    return render_template('registration/login.html')

@app.route("/logout", methods=["POST", "GET"])
def logout():
    if "email" in session:
        session.pop("email", None)
        return render_template("registration/signout.html")
    else:
        return render_template('registration/index.html')

@app.route("/deliveryboy", methods=["POST","GET"])
def register_d():
    if request.method == "POST":
        user = request.form.get("username")
        password = request.form.get("password")
        email = request.form.get("email")

        user_found = Delivery_boy.find_one({"name": user})
        email_found = Delivery_boy.find_one({"email": email})
        if user_found:
            message = 'There already is a user by that name'
            return render_template('registration/register.html', message=message)
        if email_found:
            message = 'This email already exists in database'
            return render_template('registration/register.html', message=message)
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        user_input = {'name': user, 'email': email, 'password': hashed}
        Delivery_boy.insert_one(user_input)

        user_data = Delivery_boy.find_one({"email": email})
        new_email = user_data['email']

        return render_template('registration/login.html', email=new_email)
    return render_template('registration/register.html')

@app.route("/menu_delete/<string:item_name>",methods=["DELETE","GET"])
def deletemenu(item_name):
    myquery = {"name": item_name}
    menudb.delete_one(myquery)

    f = menudb.find()
    menu_name = {}
    for i in f:
        menu_name[i['name']] = i['price']
    return render_template('user/menu.html',menu_name=menu_name)

@app.route("/menu_update/<string:item_name>",methods=["GET"])
def updatemenu(item_name):
    myquery = {"name": item_name}
    menudb.update_one(myquery)

    f = menudb.find()
    menu_name = {}
    for i in f:
        menu_name[i['name']] = i['price']
    return render_template('user/menu.html',menu_name=menu_name)


@app.route("/menu",methods=["POST","GET"])
def menu():
    f = menudb.find()
    menu_name = {}
    for i in f:
        menu_name[i['name']] = i['price']

    if request.method == "POST":
        food = request.form.get("name")
        price = request.form.get("price")

        food_found = menudb.find_one({"name": food})
        if food_found:
            message = 'There already is a user by that name'
            print('1')
            return render_template('user/menu.html', message=message,menu_name=menu_name)

        user_input = {'name': food, 'price': price}
        menudb.insert_one(user_input)
        print('3')
        return render_template('user/menu.html',menu_name=menu_name)
    print('2')
    return render_template('user/menu.html',menu_name=menu_name)

@app.route("/order",methods=["POST","GET"])
def order_d():
    f = menudb.find()
    menu = {}
    for i in f:
        menu[i['name']] = i['price']
    if request.method == "POST":
        cname = request.form.get("cname")
        food = request.form.get("food")
        qty = int(request.form.get("qty"))
        food_name = food.split('/')[0]
        food_price = food.split('/')[1]
        t_a= int(qty) * int(food_price)
        user_input = {'customer_name':cname,'name': food_name, 'count': qty,'price':t_a}
        order_table.insert_one(user_input)
        print('1')
        return render_template('user/order.html',content=menu,t_a =t_a,user_input=user_input)
    else:
        print('2')
        user_input = {}
        return render_template('user/order.html',content=menu,user_input=user_input)

@app.route("/order_total",methods=["GET"])
def total_amount():
    cname = request.form.get("cname")
    food = request.form.get("name")
    data = 1
    print("total amount")
    total = 2
    return render_template('user/order.html', content=total, check=data)

@app.route("/dashboard",methods=["GET"])
def dashboard():
    print("hi")


# end of code to run it
if __name__ == "__main__":
    app.run(debug=True)
